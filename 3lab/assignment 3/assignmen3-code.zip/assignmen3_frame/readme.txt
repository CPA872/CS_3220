We have created 5 tests here. The hex0 will display 0x1 when you run the test case successfully.
 Otherwise, it will show wrong values If you pass all tests, you will get 10 points. Below are each test case's description and its points.

1. Load, Store and Branch (2)
2. Addition without any dependency (2)
3. Addition with data dependency (2)
4. Branch instruction (2)
5. Branch instruction with data dependency (2)
